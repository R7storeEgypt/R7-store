# R7 Store

Starter Flutter project for R7 Store — a women's beauty, fashion and personal-care marketplace.

## Current version

This first milestone contains:
- R7 Store branding
- Arabic RTL interface
- Home screen
- Search field
- Promotional banner
- Main categories
- Product cards
- Bottom navigation
- Categories, Cart, Favorites and Account placeholder screens
- Local mock product/category data

## Run

1. Install Flutter.
2. From this project directory run:
   flutter pub get
3. Then:
   flutter run

## Next milestone

Connect the app to a real backend and database, then add:
- authentication
- vendors/stores
- products and inventory
- cart persistence
- orders
- payments
- shipping
- notifications
- admin dashboard