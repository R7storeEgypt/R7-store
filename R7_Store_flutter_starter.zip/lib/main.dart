import 'package:flutter/material.dart';

void main() {
  runApp(const R7StoreApp());
}

class R7StoreApp extends StatelessWidget {
  const R7StoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'R7 Store',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFFFFBFC),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE85B8B),
          brightness: Brightness.light,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class Product {
  final String name;
  final int price;
  final int oldPrice;
  final String emoji;
  final double rating;

  const Product({
    required this.name,
    required this.price,
    required this.oldPrice,
    required this.emoji,
    required this.rating,
  });

  int get discount => ((oldPrice - price) / oldPrice * 100).round();
}

const products = <Product>[
  Product(name: 'عطر روز قولد', price: 499, oldPrice: 699, emoji: '🌸', rating: 4.8),
  Product(name: 'مجموعة أحمر شفاه', price: 299, oldPrice: 399, emoji: '💄', rating: 4.7),
  Product(name: 'كريم مرطب', price: 199, oldPrice: 279, emoji: '🧴', rating: 4.6),
  Product(name: 'حقيبة نسائية', price: 599, oldPrice: 799, emoji: '👜', rating: 4.9),
];

const categories = <Map<String, String>>[
  {'name': 'مكياج', 'icon': '💄'},
  {'name': 'عناية بالبشرة', 'icon': '🧴'},
  {'name': 'عناية بالشعر', 'icon': '💇‍♀️'},
  {'name': 'لانجري', 'icon': '👙'},
  {'name': 'عطور', 'icon': '🌸'},
  {'name': 'أزياء', 'icon': '👗'},
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeTab(),
      const CategoriesTab(),
      const CartTab(),
      const FavoritesTab(),
      const AccountTab(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[selectedTab]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedTab,
          onDestinationSelected: (index) => setState(() => selectedTab = index),
          indicatorColor: const Color(0xFFFFE0EA),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'الأقسام'),
            NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'السلة'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
          ],
        ),
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'R7 STORE',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1),
                  ),
                ),
                IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
                IconButton(onPressed: () {}, icon: const Icon(Icons.shopping_cart_outlined)),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحثي عن منتج أو علامة تجارية...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: const Color(0xFFF5F1F3),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
            height: 170,
            margin: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(
                colors: [Color(0xFFFFC2D4), Color(0xFFFFE8EF)],
              ),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('عروض حصرية', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                      SizedBox(height: 6),
                      Text('خصم حتى 50%', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                      SizedBox(height: 12),
                      Chip(label: Text('تسوقي الآن')),
                    ],
                  ),
                ),
                const Text('💄🌸', style: TextStyle(fontSize: 58)),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SectionTitle(title: 'الأقسام الرئيسية')),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 108,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, index) {
                final item = categories[index];
                return SizedBox(
                  width: 82,
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: const Color(0xFFFFEAF0),
                        child: Text(item['icon']!, style: const TextStyle(fontSize: 26)),
                      ),
                      const SizedBox(height: 6),
                      Text(item['name']!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SectionTitle(title: 'الأكثر مبيعًا')),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (_, index) => ProductCard(product: products[index]),
              childCount: products.length,
            ),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: .70,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 18)),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 10),
      child: Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
          TextButton(onPressed: () {}, child: const Text('عرض الكل')),
        ],
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      clipBehavior: Clip.antiAlias,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        onTap: () {},
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: Stack(
                children: [
                  Container(
                    color: const Color(0xFFFFF0F4),
                    alignment: Alignment.center,
                    child: Text(product.emoji, style: const TextStyle(fontSize: 64)),
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.white,
                      child: const Icon(Icons.favorite_border, size: 18),
                    ),
                  ),
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE85B8B),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text('-${product.discount}%', style: const TextStyle(color: Colors.white, fontSize: 11)),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 9, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 14, color: Color(0xFFFFB400)),
                      const SizedBox(width: 3),
                      Text(product.rating.toString(), style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      Text('${product.price} ج.م', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFE85B8B))),
                      const SizedBox(width: 6),
                      Text('${product.oldPrice}', style: const TextStyle(fontSize: 11, decoration: TextDecoration.lineThrough, color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CategoriesTab extends StatelessWidget {
  const CategoriesTab({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('الأقسام', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      const SizedBox(height: 18),
      ...categories.map((c) => Card(
        elevation: 0,
        child: ListTile(
          leading: CircleAvatar(backgroundColor: const Color(0xFFFFEAF0), child: Text(c['icon']!)),
          title: Text(c['name']!, style: const TextStyle(fontWeight: FontWeight.w700)),
          trailing: const Icon(Icons.chevron_left),
          onTap: () {},
        ),
      )),
    ],
  );
}

class CartTab extends StatelessWidget {
  const CartTab({super.key});

  @override
  Widget build(BuildContext context) => const Center(
    child: Text('السلة فارغة حاليًا', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
  );
}

class FavoritesTab extends StatelessWidget {
  const FavoritesTab({super.key});

  @override
  Widget build(BuildContext context) => const Center(
    child: Text('المفضلة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
  );
}

class AccountTab extends StatelessWidget {
  const AccountTab({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('حسابي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      const SizedBox(height: 20),
      const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 42)),
      const SizedBox(height: 10),
      const Center(child: Text('زائرة R7 Store', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
      const SizedBox(height: 20),
      ...[
        ('طلباتي', Icons.receipt_long_outlined),
        ('عناويني', Icons.location_on_outlined),
        ('الإشعارات', Icons.notifications_none),
        ('الإعدادات', Icons.settings_outlined),
        ('المساعدة والدعم', Icons.help_outline),
      ].map((item) => Card(
        elevation: 0,
        child: ListTile(
          leading: Icon(item.$2),
          title: Text(item.$1),
          trailing: const Icon(Icons.chevron_left),
        ),
      )),
    ],
  );
}